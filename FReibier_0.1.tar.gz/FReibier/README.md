# FReibier
Miscellaneous R-functions from the Biometry group in Freiburg, Germany

This R-package is supposed to act as container for the little things that accumulate over the years.

To install on R, please use

    library(devtools)
    install_github("biometry/FReibier")

Any suggestions, corrections and additions are welcome!

(Maintainer: Carsten Dormann)
